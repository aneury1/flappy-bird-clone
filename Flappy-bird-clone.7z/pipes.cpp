#include "Pipes.hpp"


    
Pipe::Pipe(GameDataRef data):_data(data)
{


}

void Pipe::DrawPipes()
{
   for(unsigned short int i=0; i<pipeSprites.size(); i++)
   {
       _data->window.draw(pipeSprites.at(i));
   }

}


void Pipe::SpawnBottomPipe()
{
  sf::Sprite sprite( _data->assets->GetTexture("pipeup"));
  sprite.setPosition(_data->window.getSize().x, 0);
}
void Pipe::SpawnTopPie()
{


}
void Pipe::SpawnInvisiblePipe()
{


}
void Pipe::MovePipes()
{


}