#include "Game.hpp"
#include "def.hpp"
int main()
{
   FBC::Game(SCREEN_WIDTH,SCREEN_HEIGHT,"Great Game");
   return 0;
}